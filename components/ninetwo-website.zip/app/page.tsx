"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { motion, useScroll, useTransform, AnimatePresence } from "framer-motion"
import { TrendingUp, ChevronRight, BarChart2, Target, ArrowDown, Search, Bell, User, Zap, PieChart } from "lucide-react"

// Import tech patterns
import TechPattern from "./components/tech-pattern"
import AnimatedLines from "./components/animated-lines"
import FlowingGrid from "./components/flowing-grid"

// Animation variants
const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6 },
  },
}

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,
    },
  },
}

const floatAnimation = {
  initial: { y: 0 },
  animate: {
    y: [-10, 10, -10],
    transition: {
      duration: 6,
      repeat: Number.POSITIVE_INFINITY,
      repeatType: "loop",
      ease: "easeInOut",
    },
  },
}

const pulseAnimation = {
  initial: { scale: 1, opacity: 0.8 },
  animate: {
    scale: [1, 1.05, 1],
    opacity: [0.8, 1, 0.8],
    transition: {
      duration: 3,
      repeat: Number.POSITIVE_INFINITY,
      repeatType: "loop",
      ease: "easeInOut",
    },
  },
}

export default function Home() {
  const [scrolled, setScrolled] = useState(false)
  const [activeTab, setActiveTab] = useState("overview")
  const servicesRef = useRef(null)
  const aboutRef = useRef(null)
  const contactRef = useRef(null)
  const { scrollYProgress } = useScroll()
  const heroScale = useTransform(scrollYProgress, [0, 0.2], [1, 1.1])
  const heroOpacity = useTransform(scrollYProgress, [0, 0.2], [1, 0])

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToSection = (ref) => {
    ref.current.scrollIntoView({ behavior: "smooth" })
  }

  // Animated data for the dashboard
  const [chartData, setChartData] = useState({
    conversions: 0,
    leads: 0,
    roi: 0,
  })

  useEffect(() => {
    const timer = setTimeout(() => {
      setChartData({
        conversions: 124,
        leads: 86,
        roi: 150,
      })
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="flex min-h-screen flex-col bg-white text-gray-800">
      {/* Header */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled ? "bg-white/90 py-3 backdrop-blur-xl shadow-lg shadow-[#d00054]/10" : "bg-transparent py-5"
        }`}
      >
        <div className="container mx-auto flex items-center justify-between px-4 md:px-6">
          <Link href="/" className="flex items-center">
            <div className="relative h-8 w-32">
              <Image src="/images/logo-ninetwo.png" alt="NineTwo Logo" fill className="object-contain" priority />
            </div>
          </Link>
          <nav className="hidden md:flex items-center gap-8">
            <Link href="/" className="text-gray-800 hover:text-[#d00054] transition-colors">
              Home
            </Link>
            <button
              onClick={() => scrollToSection(servicesRef)}
              className="text-gray-800 hover:text-[#d00054] transition-colors"
            >
              Soluções
            </button>
            <button
              onClick={() => scrollToSection(aboutRef)}
              className="text-gray-800 hover:text-[#d00054] transition-colors"
            >
              Sobre
            </button>
            <button
              onClick={() => scrollToSection(contactRef)}
              className="bg-[#d00054] hover:bg-[#d00054]/90 text-white px-6 py-3 rounded-full transition-all duration-300 hover:shadow-lg hover:shadow-[#d00054]/20"
            >
              Contato
            </button>
          </nav>
          <button className="md:hidden text-gray-800">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={1.5}
              stroke="currentColor"
              className="w-6 h-6"
            >
              <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
            </svg>
          </button>
        </div>
      </header>

      {/* Hero Section - Redesigned with improved layout */}
      <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
        {/* Background with diagonal split */}
        <div className="absolute inset-0 z-0">
          {/* Left side - Dark background */}
          <div className="absolute left-0 top-0 bottom-0 w-[45%] bg-[#0f0f0f]">
            {/* Diagonal cut */}
            <div className="absolute top-0 bottom-0 right-0 w-[100px] bg-white transform skew-x-[15deg] translate-x-1/2"></div>

            {/* Animated 9 logo overlay */}
            <motion.div
              className="absolute inset-0 flex items-center justify-center"
              initial={{ opacity: 0 }}
              animate={{ opacity: [0.05, 0.08, 0.05] }}
              transition={{ duration: 8, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
            >
              <div className="relative w-[80%] aspect-square">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Camada%201-AeIrFIgywPC0BmD4iCfKUKoAaCPhPU.png"
                  alt="9 Logo"
                  fill
                  className="object-contain"
                />
              </div>
            </motion.div>
          </div>

          {/* Right side - White background */}
          <div className="absolute right-0 top-0 bottom-0 w-[55%] bg-white">
            {/* Subtle animated pattern */}
            <motion.div
              className="absolute inset-0"
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.03 }}
              transition={{ duration: 1 }}
            >
              <TechPattern variant="hexagons" color="#d00054" opacity={0.05} />
            </motion.div>
          </div>

          {/* Accent color strip */}
          <motion.div
            className="absolute top-0 left-[45%] h-full w-[3px] bg-[#d00054]"
            initial={{ height: 0 }}
            animate={{ height: "100%" }}
            transition={{ duration: 1.5, ease: "easeOut" }}
          />
        </div>

        {/* Tech patterns with reduced opacity */}
        <div className="absolute left-0 top-0 bottom-0 w-[45%] overflow-hidden">
          <AnimatedLines color="rgba(255, 255, 255, 0.2)" opacity={0.1} density="medium" />
          <FlowingGrid color="rgba(255, 255, 255, 0.2)" opacity={0.1} lineWidth={0.3} />
        </div>

        <div className="container mx-auto px-4 md:px-6 z-10 py-20">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            {/* Left column - Text content */}
            <motion.div className="text-left" initial="hidden" animate="visible" variants={staggerContainer}>
              <motion.div
                className="mb-8 relative"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8 }}
              >
                <div className="relative h-16 w-64">
                  <Image src="/images/logo-ninetwo.png" alt="NineTwo Logo" fill className="object-contain" priority />
                </div>
                <motion.div
                  className="absolute -bottom-2 left-0 h-1 bg-[#d00054]"
                  initial={{ width: 0 }}
                  animate={{ width: "80%" }}
                  transition={{ duration: 1, delay: 0.5 }}
                />
              </motion.div>

              <motion.h1 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight" variants={fadeIn}>
                <span className="text-white">Marketing de</span> <br />
                <motion.span
                  className="text-[#d00054]"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.3 }}
                >
                  Performance
                </motion.span>
              </motion.h1>

              <motion.p className="text-lg md:text-xl mb-10 text-white/90 max-w-lg" variants={fadeIn}>
                Desbloqueie o potencial do seu marketing digital e alcance resultados excepcionais com nossas soluções
                estratégicas baseadas em dados.
              </motion.p>

              <motion.div className="flex flex-wrap gap-4" variants={fadeIn}>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.98 }}>
                  <Link
                    href="#contact"
                    className="bg-[#d00054] hover:bg-[#d00054]/90 text-white px-8 py-4 rounded-full text-center font-medium transition-all duration-300 hover:shadow-lg hover:shadow-[#d00054]/20 flex items-center gap-2"
                  >
                    Quero saber mais!
                    <motion.div
                      animate={{ x: [0, 5, 0] }}
                      transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
                    >
                      <ChevronRight />
                    </motion.div>
                  </Link>
                </motion.div>

                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.98 }}>
                  <Link
                    href="#services"
                    className="border border-white/30 text-white hover:bg-white/10 px-8 py-4 rounded-full text-center font-medium transition-all duration-300"
                  >
                    Conheça nossas soluções
                  </Link>
                </motion.div>
              </motion.div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50 backdrop-blur-md relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-pink-500/30 to-transparent"></div>
          <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-pink-500/30 to-transparent"></div>
        </div>

        {/* Tech patterns */}
        <TechPattern variant="grid" color="rgba(236, 72, 153, 0.5)" opacity={0.05} />

        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <motion.div
            className="grid grid-cols-2 md:grid-cols-4 gap-6"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
          >
            <motion.div
              className="bg-white p-8 rounded-3xl text-center backdrop-blur-sm border border-gray-200 hover:border-pink-500/30 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/10"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <p className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-600 to-pink-500 mb-2">
                +200%
              </p>
              <p className="text-gray-600">de leads em 3 meses</p>
            </motion.div>
            <motion.div
              className="bg-white p-8 rounded-3xl text-center backdrop-blur-sm border border-gray-200 hover:border-pink-500/30 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/10"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <p className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-600 to-pink-500 mb-2">
                80%
              </p>
              <p className="text-gray-600">de aumento em conversões</p>
            </motion.div>
            <motion.div
              className="bg-white p-8 rounded-3xl text-center backdrop-blur-sm border border-gray-200 hover:border-pink-500/30 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/10"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <p className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-600 to-pink-500 mb-2">
                -35%
              </p>
              <p className="text-gray-600">no custo por aquisição</p>
            </motion.div>
            <motion.div
              className="bg-white p-8 rounded-3xl text-center backdrop-blur-sm border border-gray-200 hover:border-pink-500/30 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/10"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <p className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-600 to-pink-500 mb-2">
                +150%
              </p>
              <p className="text-gray-600">de ROI em campanhas</p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Marketing Challenges Section */}
      <section className="py-24 bg-white text-gray-800 relative overflow-hidden">
        <div className="absolute inset-0 z-0 overflow-hidden">
          <motion.div
            className="absolute top-[10%] right-[5%] w-96 h-96 rounded-full bg-gradient-to-r from-pink-600/5 to-purple-600/5 blur-3xl"
            animate={{
              x: [0, -50, 0],
              y: [0, 30, 0],
            }}
            transition={{
              duration: 15,
              repeat: Number.POSITIVE_INFINITY,
              repeatType: "reverse",
            }}
          />
        </div>

        {/* Tech patterns */}
        <CircuitBoard color="rgba(236, 72, 153, 0.5)" opacity={0.05} />

        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <motion.div
            className="text-center mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeIn}
          >
            <span className="inline-block bg-gradient-to-r from-pink-600/10 to-purple-600/10 backdrop-blur-md text-pink-600 px-6 py-2 rounded-full text-sm font-medium mb-4 border border-pink-500/20">
              DESAFIOS
            </span>
            <h2 className="text-3xl md:text-5xl font-bold mb-6">Quais os principais desafios do seu marketing?</h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Identificamos e solucionamos os principais obstáculos que impedem o crescimento do seu negócio
            </p>
          </motion.div>

          <motion.div
            className="grid md:grid-cols-3 gap-8"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
          >
            <motion.div
              className="bg-white p-8 rounded-3xl border border-gray-200 hover:border-pink-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/10 group"
              variants={fadeIn}
              whileHover={{ y: -10 }}
            >
              <div className="bg-gradient-to-br from-pink-600/20 to-purple-600/10 p-5 rounded-2xl w-fit mb-6 group-hover:from-pink-600/30 group-hover:to-purple-600/20 transition-all duration-300">
                <TrendingUp className="h-7 w-7 text-pink-600" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Aumento nas vendas</h3>
              <p className="text-gray-600">
                Através de uma análise minuciosa de dados, nós avaliamos junto ao seu time comercial a qualificação de
                leads e criamos planos de ação estratégicos e personalizados para aumentarmos o desempenho de suas
                vendas.
              </p>
            </motion.div>

            <motion.div
              className="bg-white p-8 rounded-3xl border border-gray-200 hover:border-pink-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/10 group"
              variants={fadeIn}
              whileHover={{ y: -10 }}
            >
              <div className="bg-gradient-to-br from-pink-600/20 to-purple-600/10 p-5 rounded-2xl w-fit mb-6 group-hover:from-pink-600/30 group-hover:to-purple-600/20 transition-all duration-300">
                <BarChart3 className="h-7 w-7 text-pink-600" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Gestão ineficiente de orçamento</h3>
              <p className="text-gray-600">
                Otimizar o orçamento das campanhas pagas é crucial para maximizar o ROI. Com nossa experiência,
                garantimos que cada centavo seja gasto de forma eficiente, focando nas estratégias que trazem os
                melhores resultados.
              </p>
            </motion.div>

            <motion.div
              className="bg-white p-8 rounded-3xl border border-gray-200 hover:border-pink-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/10 group"
              variants={fadeIn}
              whileHover={{ y: -10 }}
            >
              <div className="bg-gradient-to-br from-pink-600/20 to-purple-600/10 p-5 rounded-2xl w-fit mb-6 group-hover:from-pink-600/30 group-hover:to-purple-600/20 transition-all duration-300">
                <Clock className="h-7 w-7 text-pink-600" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Falta de tempo</h3>
              <p className="text-gray-600">
                Gerenciar campanhas pagas pode ser uma tarefa demorada. Ao terceirizar a performance, você e sua equipe
                poderão se concentrar em outras áreas importantes do marketing, como a criação de conteúdo e estratégias
                de crescimento.
              </p>
            </motion.div>

            <motion.div
              className="bg-white p-8 rounded-3xl border border-gray-200 hover:border-pink-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/10 group"
              variants={fadeIn}
              whileHover={{ y: -10 }}
            >
              <div className="bg-gradient-to-br from-pink-600/20 to-purple-600/10 p-5 rounded-2xl w-fit mb-6 group-hover:from-pink-600/30 group-hover:to-purple-600/20 transition-all duration-300">
                <LineChart className="h-7 w-7 text-pink-600" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Resultados inconsistentes</h3>
              <p className="text-gray-600">
                Campanhas de mídia paga exigem monitoramento constante e ajustes precisos. Nossa abordagem baseada em
                dados e nossa dashboard atualizada em tempo real assegura que as campanhas do seu negócio estejam sempre
                otimizadas.
              </p>
            </motion.div>

            <motion.div
              className="bg-white p-8 rounded-3xl border border-gray-200 hover:border-pink-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/10 group"
              variants={fadeIn}
              whileHover={{ y: -10 }}
            >
              <div className="bg-gradient-to-br from-pink-600/20 to-purple-600/10 p-5 rounded-2xl w-fit mb-6 group-hover:from-pink-600/30 group-hover:to-purple-600/20 transition-all duration-300">
                <Target className="h-7 w-7 text-pink-600" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Estratégias de crescimento</h3>
              <p className="text-gray-600">
                O crescimento é mais do que um objetivo; é uma jornada. Juntos, podemos desenvolver estratégias que
                impulsionam seu crescimento imediato, estabelecendo bases sólidas para o sucesso contínuo do seu
                negócio.
              </p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* CTA Banner with Parallax */}
      <section className="py-24 relative overflow-hidden">
        <motion.div
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: "url('/pink-abstract-bg.png')",
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
          initial={{ y: 0 }}
          whileInView={{ y: -20 }}
          transition={{ duration: 1.5 }}
          viewport={{ once: false }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-pink-600/90 via-pink-500/90 to-purple-600/90"></div>

        {/* Tech patterns */}
        <TechPattern variant="waves" color="rgba(255, 255, 255, 0.3)" opacity={0.15} />
        <DataFlow color="rgba(255, 255, 255, 0.5)" opacity={0.1} speed="slow" />

        <div className="py-24 relative">
          <div className="container mx-auto px-4 md:px-6">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <motion.div
                className="text-left"
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-100px" }}
                variants={fadeIn}
              >
                <h2 className="text-3xl md:text-5xl font-bold mb-6 text-white">
                  PERFORMANCE DE <br />
                  <span className="text-white/90">ALTO NÍVEL</span>
                </h2>
                <p className="text-xl mb-10 max-w-xl text-white">
                  Transformamos estratégias em resultados mensuráveis para o seu negócio através de análise de dados e
                  otimização contínua.
                </p>
                <div className="flex flex-wrap gap-4 mb-8">
                  <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full">
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 8, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                      className="text-white"
                    >
                      <TrendingUp size={20} />
                    </motion.div>
                    <span className="text-sm text-white">Crescimento acelerado</span>
                  </div>
                  <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full">
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                      className="text-white"
                    >
                      <Target size={20} />
                    </motion.div>
                    <span className="text-sm text-white">Resultados precisos</span>
                  </div>
                  <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full">
                    <motion.div
                      animate={{ y: [0, -5, 0] }}
                      transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                      className="text-white"
                    >
                      <BarChart2 size={20} />
                    </motion.div>
                    <span className="text-sm text-white">Métricas em tempo real</span>
                  </div>
                </div>
                <Link
                  href="#contact"
                  className="bg-white hover:bg-white/90 text-pink-600 font-medium px-10 py-5 rounded-full text-center inline-flex items-center gap-2 transition-all duration-300 hover:gap-3 shadow-lg shadow-pink-600/20"
                >
                  Falar com Especialista
                  <ChevronRight className="h-5 w-5" />
                </Link>
              </motion.div>

              <motion.div
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-100px" }}
                variants={fadeIn}
                className="relative h-[400px] hidden md:block"
              >
                <div className="absolute inset-0 flex items-center justify-center">
                  <motion.div
                    className="relative w-64 h-64"
                    animate={{ rotate: 360 }}
                    transition={{ duration: 50, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                  >
                    <div className="absolute inset-0 rounded-full border-4 border-dashed border-white/20"></div>
                  </motion.div>

                  <motion.div
                    className="absolute w-48 h-48 rounded-full bg-gradient-to-r from-white/20 to-white/10 backdrop-blur-md"
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 8, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse" }}
                  ></motion.div>

                  <motion.div
                    className="absolute flex flex-col items-center justify-center text-center"
                    animate={{ scale: [0.9, 1, 0.9] }}
                    transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse" }}
                  >
                    <div className="bg-white/10 backdrop-blur-md p-6 rounded-full mb-4">
                      <motion.div
                        animate={{
                          rotateY: [0, 180, 360],
                          scale: [1, 1.2, 1],
                        }}
                        transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
                      >
                        <Award className="h-12 w-12 text-white" />
                      </motion.div>
                    </div>
                    <p className="text-xl font-bold text-white">Resultados Comprovados</p>
                    <p className="text-sm text-white/80">Estratégias que funcionam</p>
                  </motion.div>

                  <motion.div
                    className="absolute top-0 left-20"
                    animate={{ y: [0, -15, 0] }}
                    transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse" }}
                  >
                    <div className="bg-white/10 backdrop-blur-md p-3 rounded-full">
                      <LineChart className="h-6 w-6 text-white" />
                    </div>
                  </motion.div>

                  <motion.div
                    className="absolute bottom-10 right-10"
                    animate={{ y: [0, 15, 0] }}
                    transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse", delay: 1 }}
                  >
                    <div className="bg-white/10 backdrop-blur-md p-3 rounded-full">
                      <BarChart3 className="h-6 w-6 text-white" />
                    </div>
                  </motion.div>

                  <motion.div
                    className="absolute bottom-20 left-0"
                    animate={{ x: [0, 15, 0] }}
                    transition={{ duration: 5, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse", delay: 0.5 }}
                  >
                    <div className="bg-white/10 backdrop-blur-md p-3 rounded-full">
                      <BrainCircuit className="h-6 w-6 text-white" />
                    </div>
                  </motion.div>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section ref={servicesRef} className="py-24 bg-white text-gray-800 relative overflow-hidden" id="services">
        <div className="absolute inset-0 z-0 overflow-hidden">
          <motion.div
            className="absolute bottom-[20%] left-[5%] w-96 h-96 rounded-full bg-gradient-to-r from-pink-600/5 to-purple-600/5 blur-3xl"
            animate={{
              x: [0, 50, 0],
              y: [0, -30, 0],
            }}
            transition={{
              duration: 15,
              repeat: Number.POSITIVE_INFINITY,
              repeatType: "reverse",
            }}
          />
        </div>

        {/* Tech patterns */}
        <TechPattern variant="hexagons" color="rgba(236, 72, 153, 0.5)" opacity={0.05} />
        <BinaryRain color="rgba(236, 72, 153, 0.5)" opacity={0.03} speed="slow" density="low" />

        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <motion.div
            className="text-center mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeIn}
          >
            <span className="inline-block bg-gradient-to-r from-pink-600/10 to-purple-600/10 backdrop-blur-md text-pink-600 px-6 py-2 rounded-full text-sm font-medium mb-4 border border-pink-500/20">
              SOLUÇÕES
            </span>
            <h2 className="text-3xl md:text-5xl font-bold mb-6">Como podemos ser seu braço direito?</h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Oferecemos soluções completas e personalizadas para impulsionar seu negócio
            </p>
          </motion.div>

          <motion.div
            className="grid md:grid-cols-3 gap-8"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
          >
            <motion.div
              className="bg-white p-8 rounded-3xl border border-gray-200 hover:border-pink-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/10 group"
              variants={fadeIn}
              whileHover={{ y: -10 }}
            >
              <div className="bg-gradient-to-br from-pink-600/20 to-purple-600/10 p-5 rounded-2xl w-fit mb-6 group-hover:from-pink-600/30 group-hover:to-purple-600/20 transition-all duration-300">
                <Megaphone className="h-7 w-7 text-pink-600" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Auditoria e otimização dos canais digitais</h3>
              <p className="text-gray-600">
                Realizamos um estudo detalhado de todas as campanhas já existentes, mapeando inconsistências e ajustando
                estratégias para maximizar a eficiência e os resultados.
              </p>
            </motion.div>

            <motion.div
              className="bg-white p-8 rounded-3xl border border-gray-200 hover:border-pink-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/10 group"
              variants={fadeIn}
              whileHover={{ y: -10 }}
            >
              <div className="bg-gradient-to-br from-pink-600/20 to-purple-600/10 p-5 rounded-2xl w-fit mb-6 group-hover:from-pink-600/30 group-hover:to-purple-600/20 transition-all duration-300">
                <BrainCircuit className="h-7 w-7 text-pink-600" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Entendimento profundo sobre o negócio</h3>
              <p className="text-gray-600">
                Buscamos entender a fundo todas as necessidades e dinâmicas do seu negócio, incluindo público-alvo,
                mercado e concorrência, para desenvolver estratégias altamente eficazes.
              </p>
            </motion.div>

            <motion.div
              className="bg-white p-8 rounded-3xl border border-gray-200 hover:border-pink-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/10 group"
              variants={fadeIn}
              whileHover={{ y: -10 }}
            >
              <div className="bg-gradient-to-br from-pink-600/20 to-purple-600/10 p-5 rounded-2xl w-fit mb-6 group-hover:from-pink-600/30 group-hover:to-purple-600/20 transition-all duration-300">
                <LineChart className="h-7 w-7 text-pink-600" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Construção da jornada de compra</h3>
              <p className="text-gray-600">
                Construímos toda a jornada de compra para o cliente, levando em consideração todas as etapas do funil de
                vendas, desde a conscientização até as fases de conversão e fidelização.
              </p>
            </motion.div>

            <motion.div
              className="bg-white p-8 rounded-3xl border border-gray-200 hover:border-pink-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/10 group"
              variants={fadeIn}
              whileHover={{ y: -10 }}
            >
              <div className="bg-gradient-to-br from-pink-600/20 to-purple-600/10 p-5 rounded-2xl w-fit mb-6 group-hover:from-pink-600/30 group-hover:to-purple-600/20 transition-all duration-300">
                <TrendingUp className="h-7 w-7 text-pink-600" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Foco em resultados</h3>
              <p className="text-gray-600">
                Utilizamos uma abordagem baseada em dados para maximizar o retorno sobre investimento (ROAS) das
                campanhas de seus clientes.
              </p>
            </motion.div>

            <motion.div
              className="bg-white p-8 rounded-3xl border border-gray-200 hover:border-pink-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/10 group"
              variants={fadeIn}
              whileHover={{ y: -10 }}
            >
              <div className="bg-gradient-to-br from-pink-600/20 to-purple-600/10 p-5 rounded-2xl w-fit mb-6 group-hover:from-pink-600/30 group-hover:to-purple-600/20 transition-all duration-300">
                <BarChart2 className="h-7 w-7 text-pink-600" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Gestão eficiente de orçamento</h3>
              <p className="text-gray-600">
                Nossa experiência permite otimizar cada centavo investido, assegurando que o orçamento das campanhas
                seja utilizado da maneira mais eficiente possível.
              </p>
            </motion.div>

            <motion.div
              className="bg-white p-8 rounded-3xl border border-gray-200 hover:border-pink-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/10 group"
              variants={fadeIn}
              whileHover={{ y: -10 }}
            >
              <div className="bg-gradient-to-br from-pink-600/20 to-purple-600/10 p-5 rounded-2xl w-fit mb-6 group-hover:from-pink-600/30 group-hover:to-purple-600/20 transition-all duration-300">
                <Clock className="h-7 w-7 text-pink-600" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Monitoramento contínuo</h3>
              <p className="text-gray-600">
                Realizamos monitoramento constante e ajustes precisos nas campanhas, garantindo resultados consistentes
                e superiores.
              </p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Marketing Performance Section */}
      <section className="py-24 relative overflow-hidden bg-gray-50">
        <motion.div
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: "url('/gradient-bg.png')",
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
          initial={{ y: 0 }}
          whileInView={{ y: -20 }}
          transition={{ duration: 1.5 }}
          viewport={{ once: false }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-gray-50/95 via-gray-50/90 to-gray-50/95"></div>

        {/* Tech patterns */}
        <CircuitBoard color="rgba(236, 72, 153, 0.5)" opacity={0.05} />
        <DataFlow color="rgba(236, 72, 153, 0.5)" opacity={0.03} speed="medium" density="medium" />

        <div className="py-24 relative">
          <div className="container mx-auto px-4 md:px-6">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-100px" }}
                variants={fadeIn}
              >
                <span className="inline-block bg-gradient-to-r from-pink-600/10 to-purple-600/10 backdrop-blur-md text-pink-600 px-6 py-2 rounded-full text-sm font-medium mb-4 border border-pink-500/20">
                  NOSSAS SOLUÇÕES
                </span>
                <h2 className="text-3xl md:text-5xl font-bold mb-6">Marketing de Performance</h2>
                <p className="text-gray-700 mb-6">
                  Tenha novos clientes todos os dias interessados em seus produtos ou serviços com a gestão eficiente de
                  anúncios no Google Ads, Meta Ads, LinkedIn Ads e outros canais de mídia paga, alcançando seu
                  público-alvo com precisão e impulsionando conversões.
                </p>

                <div className="flex flex-wrap gap-3 mb-8">
                  <span className="bg-gradient-to-r from-pink-600/10 to-purple-600/10 backdrop-blur-md text-pink-600 px-5 py-2 rounded-full text-sm border border-pink-500/20">
                    Escala de faturamento
                  </span>
                  <span className="bg-gradient-to-r from-pink-600/10 to-purple-600/10 backdrop-blur-md text-pink-600 px-5 py-2 rounded-full text-sm border border-pink-500/20">
                    Campanhas baseadas em dados
                  </span>
                  <span className="bg-gradient-to-r from-pink-600/10 to-purple-600/10 backdrop-blur-md text-pink-600 px-5 py-2 rounded-full text-sm border border-pink-500/20">
                    Segmentação eficiente
                  </span>
                  <span className="bg-gradient-to-r from-pink-600/10 to-purple-600/10 backdrop-blur-md text-pink-600 px-5 py-2 rounded-full text-sm border border-pink-500/20">
                    Aumento de ROI
                  </span>
                  <span className="bg-gradient-to-r from-pink-600/10 to-purple-600/10 backdrop-blur-md text-pink-600 px-5 py-2 rounded-full text-sm border border-pink-500/20">
                    Análise de métricas
                  </span>
                </div>

                <Link
                  href="#contact"
                  className="bg-gradient-to-r from-pink-600 to-pink-500 hover:from-pink-700 hover:to-pink-600 text-white px-8 py-4 rounded-full text-center font-medium inline-flex items-center gap-2 transition-all duration-300 hover:gap-3"
                >
                  Fale com um especialista
                  <ChevronRight className="h-5 w-5" />
                </Link>
              </motion.div>

              <motion.div
                className="relative h-[500px] rounded-3xl overflow-hidden"
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-100px" }}
                variants={fadeIn}
              >
                <Image
                  src="/marketing-performance.jpg"
                  alt="Marketing de Performance"
                  fill
                  className="object-cover rounded-3xl"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/50 to-transparent"></div>
                <div className="absolute bottom-0 left-0 right-0 p-8">
                  <div className="bg-white/90 backdrop-blur-md p-8 rounded-3xl border border-gray-200 shadow-lg">
                    <h3 className="text-xl font-bold mb-4 text-gray-800">Resultados que você pode esperar:</h3>
                    <ul className="space-y-3">
                      <li className="flex items-center gap-3">
                        <div className="bg-gradient-to-r from-pink-600/20 to-purple-600/10 p-2 rounded-full">
                          <CheckCircle className="h-5 w-5 text-pink-600 flex-shrink-0" />
                        </div>
                        <span className="text-gray-700">Aumento significativo em leads qualificados</span>
                      </li>
                      <li className="flex items-center gap-3">
                        <div className="bg-gradient-to-r from-pink-600/20 to-purple-600/10 p-2 rounded-full">
                          <CheckCircle className="h-5 w-5 text-pink-600 flex-shrink-0" />
                        </div>
                        <span className="text-gray-700">Redução do custo por aquisição (CPA)</span>
                      </li>
                      <li className="flex items-center gap-3">
                        <div className="bg-gradient-to-r from-pink-600/20 to-purple-600/10 p-2 rounded-full">
                          <CheckCircle className="h-5 w-5 text-pink-600 flex-shrink-0" />
                        </div>
                        <span className="text-gray-700">Maior taxa de conversão em suas campanhas</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Certifications Section */}
      <section className="py-16 bg-white text-gray-800 relative overflow-hidden">
        <div className="absolute inset-0 z-0 overflow-hidden">
          <motion.div
            className="absolute top-[30%] right-[10%] w-80 h-80 rounded-full bg-gradient-to-r from-pink-600/5 to-purple-600/5 blur-3xl"
            animate={{
              x: [0, -40, 0],
              y: [0, 20, 0],
            }}
            transition={{
              duration: 12,
              repeat: Number.POSITIVE_INFINITY,
              repeatType: "reverse",
            }}
          />
        </div>

        {/* Tech patterns */}
        <TechPattern variant="dots" color="rgba(236, 72, 153, 0.5)" opacity={0.05} />

        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <motion.div
            className="text-center mb-12"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeIn}
          >
            <span className="inline-block bg-gradient-to-r from-pink-600/10 to-purple-600/10 backdrop-blur-md text-pink-600 px-6 py-2 rounded-full text-sm font-medium mb-4 border border-pink-500/20">
              CREDIBILIDADE
            </span>
            <h2 className="text-3xl md:text-4xl font-bold mb-8">SOMOS CERTIFICADOS</h2>
          </motion.div>

          <motion.div
            className="grid grid-cols-2 md:grid-cols-4 gap-8"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
          >
            <motion.div
              className="bg-pink-600 p-6 rounded-3xl flex items-center justify-center h-28 border border-pink-200 shadow-sm hover:shadow-md backdrop-blur-sm"
              variants={fadeIn}
              whileHover={{ scale: 1.05, borderColor: "rgba(236, 72, 153, 0.5)" }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <div className="relative h-12 w-full">
                <Image src="/images/google-partner.png" alt="Google Partner" fill className="object-contain" />
              </div>
            </motion.div>
            <motion.div
              className="bg-pink-600 p-6 rounded-3xl flex items-center justify-center h-28 border border-pink-200 shadow-sm hover:shadow-md backdrop-blur-sm"
              variants={fadeIn}
              whileHover={{ scale: 1.05, borderColor: "rgba(236, 72, 153, 0.5)" }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <div className="relative h-12 w-full">
                <Image src="/images/meta-partner.png" alt="Meta Business Partner" fill className="object-contain" />
              </div>
            </motion.div>
            <motion.div
              className="bg-pink-600 p-6 rounded-3xl flex items-center justify-center h-28 border border-pink-200 shadow-sm hover:shadow-md backdrop-blur-sm"
              variants={fadeIn}
              whileHover={{ scale: 1.05, borderColor: "rgba(236, 72, 153, 0.5)" }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <div className="relative h-12 w-full">
                <Image src="/images/google-cloud.png" alt="Google Cloud Partner" fill className="object-contain" />
              </div>
            </motion.div>
            <motion.div
              className="bg-pink-600 p-6 rounded-3xl flex items-center justify-center h-28 border border-pink-200 shadow-sm hover:shadow-md backdrop-blur-sm"
              variants={fadeIn}
              whileHover={{ scale: 1.05, borderColor: "rgba(236, 72, 153, 0.5)" }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <div className="text-pink-600 font-medium">LinkedIn Ads Partner</div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Clients Section */}
      <section className="py-20 relative overflow-hidden bg-gray-50">
        <motion.div
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: "url('/dark-gradient-bg.png')",
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
          initial={{ y: 0 }}
          whileInView={{ y: -20 }}
          transition={{ duration: 1.5 }}
          viewport={{ once: false }}
        />
        <div className="absolute inset-0 bg-gray-50/90 backdrop-blur-sm"></div>

        {/* Tech patterns */}
        <TechPattern variant="grid" color="rgba(236, 72, 153, 0.5)" opacity={0.05} />
        <BinaryRain color="rgba(236, 72, 153, 0.5)" opacity={0.03} speed="medium" density="low" />

        <div className="py-20 relative">
          <div className="container mx-auto px-4 md:px-6">
            <motion.div
              className="text-center mb-12"
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-100px" }}
              variants={fadeIn}
            >
              <span className="inline-block bg-gradient-to-r from-pink-600/10 to-purple-600/10 backdrop-blur-md text-pink-600 px-6 py-2 rounded-full text-sm font-medium mb-4 border border-pink-500/20">
                CLIENTES
              </span>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-800">
                MAIS DE 100 MARCAS CONFIAM NA NINETWO
              </h2>
              <p className="text-gray-600 max-w-3xl mx-auto">
                Empresas de diversos segmentos que transformaram seus resultados com nossas soluções
              </p>
            </motion.div>

            <motion.div
              className="grid grid-cols-2 md:grid-cols-5 gap-6"
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-100px" }}
              variants={staggerContainer}
            >
              <motion.div
                className="bg-white p-6 rounded-3xl flex items-center justify-center h-28 border border-gray-200 shadow-sm hover:shadow-md backdrop-blur-md"
                variants={fadeIn}
                whileHover={{ scale: 1.05, borderColor: "rgba(236, 72, 153, 0.3)" }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="relative h-12 w-full">
                  <Image src="/images/client-1.png" alt="Cliente 1" fill className="object-contain" />
                </div>
              </motion.div>
              <motion.div
                className="bg-white p-6 rounded-3xl flex items-center justify-center h-28 border border-gray-200 shadow-sm hover:shadow-md backdrop-blur-md"
                variants={fadeIn}
                whileHover={{ scale: 1.05, borderColor: "rgba(236, 72, 153, 0.3)" }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="relative h-12 w-full">
                  <Image src="/images/client-2.png" alt="Cliente 2" fill className="object-contain" />
                </div>
              </motion.div>
              <motion.div
                className="bg-white p-6 rounded-3xl flex items-center justify-center h-28 border border-gray-200 shadow-sm hover:shadow-md backdrop-blur-md"
                variants={fadeIn}
                whileHover={{ scale: 1.05, borderColor: "rgba(236, 72, 153, 0.3)" }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="relative h-12 w-full">
                  <Image src="/images/client-3.png" alt="Cliente 3" fill className="object-contain" />
                </div>
              </motion.div>
              <motion.div
                className="bg-white p-6 rounded-3xl flex items-center justify-center h-28 border border-gray-200 shadow-sm hover:shadow-md backdrop-blur-md"
                variants={fadeIn}
                whileHover={{ scale: 1.05, borderColor: "rgba(236, 72, 153, 0.3)" }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="relative h-12 w-full">
                  <Image src="/images/client-4.png" alt="Cliente 4" fill className="object-contain" />
                </div>
              </motion.div>
              <motion.div
                className="bg-white p-6 rounded-3xl flex items-center justify-center h-28 border border-gray-200 shadow-sm hover:shadow-md backdrop-blur-md"
                variants={fadeIn}
                whileHover={{ scale: 1.05, borderColor: "rgba(236, 72, 153, 0.3)" }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="relative h-12 w-full">
                  <Image src="/images/client-5.png" alt="Cliente 5" fill className="object-contain" />
                </div>
              </motion.div>
              <motion.div
                className="bg-white p-6 rounded-3xl flex items-center justify-center h-28 border border-gray-200 shadow-sm hover:shadow-md backdrop-blur-md"
                variants={fadeIn}
                whileHover={{ scale: 1.05, borderColor: "rgba(236, 72, 153, 0.3)" }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="relative h-12 w-full">
                  <Image src="/images/client-6.png" alt="Cliente 6" fill className="object-contain" />
                </div>
              </motion.div>
              <motion.div
                className="bg-white p-6 rounded-3xl flex items-center justify-center h-28 border border-gray-200 shadow-sm hover:shadow-md backdrop-blur-md"
                variants={fadeIn}
                whileHover={{ scale: 1.05, borderColor: "rgba(236, 72, 153, 0.3)" }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="relative h-12 w-full">
                  <Image src="/images/client-7.png" alt="Cliente 7" fill className="object-contain" />
                </div>
              </motion.div>
              <motion.div
                className="bg-white p-6 rounded-3xl flex items-center justify-center h-28 border border-gray-200 shadow-sm hover:shadow-md backdrop-blur-md"
                variants={fadeIn}
                whileHover={{ scale: 1.05, borderColor: "rgba(236, 72, 153, 0.3)" }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="relative h-12 w-full">
                  <Image src="/images/client-8.png" alt="Cliente 8" fill className="object-contain" />
                </div>
              </motion.div>
              <motion.div
                className="bg-white p-6 rounded-3xl flex items-center justify-center h-28 border border-gray-200 shadow-sm hover:shadow-md backdrop-blur-md"
                variants={fadeIn}
                whileHover={{ scale: 1.05, borderColor: "rgba(236, 72, 153, 0.3)" }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="relative h-12 w-full">
                  <Image src="/images/client-9.png" alt="Cliente 9" fill className="object-contain" />
                </div>
              </motion.div>
              <motion.div
                className="bg-white p-6 rounded-3xl flex items-center justify-center h-28 border border-gray-200 shadow-sm hover:shadow-md backdrop-blur-md"
                variants={fadeIn}
                whileHover={{ scale: 1.05, borderColor: "rgba(236, 72, 153, 0.3)" }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="relative h-12 w-full">
                  <Image src="/images/client-10.png" alt="Cliente 10" fill className="object-contain" />
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section ref={contactRef} className="py-24 bg-gray-50 text-gray-800 relative overflow-hidden" id="contact">
        <div className="absolute inset-0 z-0 overflow-hidden">
          <motion.div
            className="absolute bottom-[20%] right-[10%] w-96 h-96 rounded-full bg-gradient-to-r from-pink-600/5 to-purple-600/5 blur-3xl"
            animate={{
              x: [0, -30, 0],
              y: [0, 30, 0],
            }}
            transition={{
              duration: 10,
              repeat: Number.POSITIVE_INFINITY,
              repeatType: "reverse",
            }}
          />
        </div>

        {/* Tech patterns */}
        <CircuitBoard color="rgba(236, 72, 153, 0.5)" opacity={0.05} />
        <BinaryRain color="rgba(236, 72, 153, 0.5)" opacity={0.03} speed="medium" density="low" />

        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <motion.div
            className="max-w-3xl mx-auto text-center mb-12"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeIn}
          >
            <span className="inline-block bg-gradient-to-r from-pink-600/10 to-purple-600/10 backdrop-blur-md text-pink-600 px-6 py-2 rounded-full text-sm font-medium mb-4 border border-pink-500/20">
              CONTATO
            </span>
            <h2 className="text-3xl md:text-5xl font-bold mb-6 text-gray-800">Leve sua Marca para o topo!</h2>
            <p className="text-gray-700 mb-8">
              Preencha seus dados agora e aguarde nosso contato para apresentação de nossas soluções:
            </p>
          </motion.div>

          <motion.div
            className="max-w-md mx-auto"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeIn}
          >
            <div className="space-y-4 bg-white/90 backdrop-blur-md p-8 rounded-3xl border border-gray-200 shadow-lg">
              <div>
                <label htmlFor="name" className="block text-sm font-medium mb-2 text-gray-700">
                  Nome
                </label>
                <input
                  type="text"
                  id="name"
                  className="w-full px-4 py-3 bg-white border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-pink-600 focus:border-transparent"
                  placeholder="Seu nome completo"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium mb-2 text-gray-700">
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  className="w-full px-4 py-3 bg-white border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-pink-600 focus:border-transparent"
                  placeholder="seu@email.com"
                />
              </div>
              <div>
                <label htmlFor="phone" className="block text-sm font-medium mb-2 text-gray-700">
                  Telefone
                </label>
                <input
                  type="tel"
                  id="phone"
                  className="w-full px-4 py-3 bg-white border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-pink-600 focus:border-transparent"
                  placeholder="(00) 00000-0000"
                />
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium mb-2 text-gray-700">
                  Mensagem (opcional)
                </label>
                <textarea
                  id="message"
                  rows={4}
                  className="w-full px-4 py-3 bg-white border border-gray-300 rounded-2xl focus:outline-none focus:ring-2 focus:ring-pink-600 focus:border-transparent"
                  placeholder="Como podemos ajudar?"
                ></textarea>
              </div>
              <button
                type="button"
                className="w-full bg-gradient-to-r from-pink-600 to-pink-500 hover:from-pink-700 hover:to-pink-600 text-white py-4 rounded-full font-medium transition-all duration-300 hover:shadow-lg hover:shadow-pink-600/30"
              >
                Enviar
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-16 bg-white text-gray-800 border-t border-gray-200 relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-pink-500/30 to-transparent"></div>
        </div>

        {/* Tech patterns */}
        <TechPattern variant="dots" color="rgba(236, 72, 153, 0.5)" opacity={0.05} />

        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="grid md:grid-cols-3 gap-12 mb-12">
            <div>
              <div className="relative h-8 w-32 mb-6">
                <Image src="/images/logo-ninetwo.png" alt="NineTwo Logo" fill className="object-contain" />
              </div>
              <p className="text-gray-600 mb-4">Uma empresa Catalisti Holding.</p>
              <p className="text-gray-600 mb-4">Rua Jerônimo Durski, 866, Bigorrilho, Curitiba (PR), 80730-290</p>
              <p className="text-gray-600">contato@ninetwo.com.br</p>
              <p className="text-gray-600">(41) 98715-0786</p>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">Links Rápidos</h3>
              <ul className="space-y-3">
                <li>
                  <Link
                    href="/"
                    className="text-gray-600 hover:text-pink-600 transition-colors flex items-center gap-2"
                  >
                    <ChevronRight className="h-4 w-4 text-pink-600" />
                    Home
                  </Link>
                </li>
                <li>
                  <Link
                    href="#services"
                    className="text-gray-600 hover:text-pink-600 transition-colors flex items-center gap-2"
                  >
                    <ChevronRight className="h-4 w-4 text-pink-600" />
                    Soluções
                  </Link>
                </li>
                <li>
                  <Link
                    href="/cases"
                    className="text-gray-600 hover:text-pink-600 transition-colors flex items-center gap-2"
                  >
                    <ChevronRight className="h-4 w-4 text-pink-600" />
                    Cases
                  </Link>
                </li>
                <li>
                  <Link
                    href="#about"
                    className="text-gray-600 hover:text-pink-600 transition-colors flex items-center gap-2"
                  >
                    <ChevronRight className="h-4 w-4 text-pink-600" />
                    Sobre
                  </Link>
                </li>
                <li>
                  <Link
                    href="#contact"
                    className="text-gray-600 hover:text-pink-600 transition-colors flex items-center gap-2"
                  >
                    <ChevronRight className="h-4 w-4 text-pink-600" />
                    Contato
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">Redes Sociais</h3>
              <div className="flex gap-4 mb-6">
                <a
                  href="#"
                  className="bg-gray-100 hover:bg-gradient-to-r hover:from-pink-600 hover:to-pink-500 hover:text-white text-gray-600 p-3 rounded-full transition-colors"
                >
                  <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" />
                  </svg>
                </a>
                <a
                  href="#"
                  className="bg-gray-100 hover:bg-gradient-to-r hover:from-pink-600 hover:to-pink-500 hover:text-white text-gray-600 p-3 rounded-full transition-colors"
                >
                  <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                  </svg>
                </a>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-200 pt-8 text-center">
            <p className="text-gray-500">
              © {new Date().getFullYear()} Nine Two - Performance Digital. Todos os direitos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
