"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { motion, useScroll, useTransform } from "framer-motion"
import {
  BarChart3,
  BrainCircuit,
  Clock,
  TrendingUp,
  LineChart,
  ChevronRight,
  BarChart2,
  Target,
  Award,
  ArrowDown,
} from "lucide-react"

// Import tech patterns
import TechPattern from "./components/tech-pattern"
import DataFlow from "./components/data-flow"
import BinaryRain from "./components/binary-rain"
import CircuitBoard from "./components/circuit-board"

// Animation variants
const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6 },
  },
}

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,
    },
  },
}

const floatAnimation = {
  initial: { y: 0 },
  animate: {
    y: [-10, 10, -10],
    transition: {
      duration: 6,
      repeat: Number.POSITIVE_INFINITY,
      repeatType: "loop",
      ease: "easeInOut",
    },
  },
}

export default function Home() {
  const [scrolled, setScrolled] = useState(false)
  const servicesRef = useRef(null)
  const aboutRef = useRef(null)
  const contactRef = useRef(null)
  const { scrollYProgress } = useScroll()
  const heroScale = useTransform(scrollYProgress, [0, 0.2], [1, 1.1])
  const heroOpacity = useTransform(scrollYProgress, [0, 0.2], [1, 0])

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToSection = (ref) => {
    ref.current.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <div className="flex min-h-screen flex-col bg-white text-gray-900">
      {/* Header */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled ? "bg-white/90 py-3 backdrop-blur-xl shadow-lg shadow-pink-600/10" : "bg-transparent py-5"
        }`}
      >
        <div className="container mx-auto flex items-center justify-between px-4 md:px-6">
          <Link href="/" className="flex items-center">
            <div className="relative h-8 w-32">
              <Image src="/images/logo-ninetwo.png" alt="NineTwo Logo" fill className="object-contain" priority />
            </div>
          </Link>
          <nav className="hidden md:flex items-center gap-8">
            <Link href="/" className="text-gray-800 hover:text-pink-500 transition-colors">
              Home
            </Link>
            <button
              onClick={() => scrollToSection(servicesRef)}
              className="text-gray-800 hover:text-pink-500 transition-colors"
            >
              Soluções
            </button>
            <button
              onClick={() => scrollToSection(aboutRef)}
              className="text-gray-800 hover:text-pink-500 transition-colors"
            >
              Sobre
            </button>
            <button
              onClick={() => scrollToSection(contactRef)}
              className="bg-gradient-to-r from-pink-600 to-pink-500 hover:from-pink-700 hover:to-pink-600 text-white px-6 py-3 rounded-full transition-all duration-300 hover:shadow-lg hover:shadow-pink-600/20"
            >
              Contato
            </button>
          </nav>
          <button className="md:hidden text-gray-800">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={1.5}
              stroke="currentColor"
              className="w-6 h-6"
            >
              <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
            </svg>
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center bg-gradient-to-b from-white to-gray-100 text-gray-900 pt-20 overflow-hidden">
        <motion.div className="absolute inset-0 z-0" style={{ scale: heroScale, opacity: heroOpacity }}>
          <Image
            src="/hero-background.png"
            alt="Analytics Dashboard"
            fill
            className="object-cover opacity-10"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-b from-white/70 via-white/80 to-white/90"></div>
        </motion.div>

        {/* Tech patterns */}
        <BinaryRain color="rgba(236, 72, 153, 0.5)" opacity={0.05} speed="medium" density="medium" />
        <TechPattern variant="hexagons" color="rgba(236, 72, 153, 0.5)" opacity={0.05} />

        {/* Animated background shapes */}
        <div className="absolute inset-0 z-0 overflow-hidden">
          <motion.div
            className="absolute top-[20%] left-[10%] w-64 h-64 rounded-full bg-gradient-to-r from-pink-600/10 to-purple-600/5 blur-3xl"
            animate={{
              x: [0, 30, 0],
              y: [0, -30, 0],
            }}
            transition={{
              duration: 8,
              repeat: Number.POSITIVE_INFINITY,
              repeatType: "reverse",
            }}
          />
          <motion.div
            className="absolute bottom-[30%] right-[15%] w-72 h-72 rounded-full bg-gradient-to-r from-pink-500/5 to-purple-500/10 blur-3xl"
            animate={{
              x: [0, -40, 0],
              y: [0, 40, 0],
            }}
            transition={{
              duration: 10,
              repeat: Number.POSITIVE_INFINITY,
              repeatType: "reverse",
            }}
          />
        </div>

        <div className="container mx-auto px-4 md:px-6 z-10 py-20">
          <motion.div
            className="max-w-3xl mx-auto text-center"
            initial="hidden"
            animate="visible"
            variants={staggerContainer}
          >
            <motion.div variants={fadeIn}>
              <span className="inline-block bg-gradient-to-r from-pink-600/10 to-purple-600/10 backdrop-blur-md text-pink-600 px-6 py-2 rounded-full text-sm font-medium mb-6 border border-pink-500/20">
                NINETWO PERFORMANCE
              </span>
            </motion.div>
            <motion.h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight text-gray-900" variants={fadeIn}>
              Mais do que marketing, <br />
              entregamos{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-600 to-pink-500">
                performance
              </span>
            </motion.h1>
            <motion.p className="text-lg md:text-xl mb-10 text-gray-700 max-w-2xl mx-auto" variants={fadeIn}>
              Desbloqueie o potencial do seu marketing digital e alcance resultados excepcionais com nossas soluções
              estratégicas baseadas em dados.
            </motion.p>
            <motion.div className="flex flex-col sm:flex-row gap-4 justify-center" variants={fadeIn}>
              <Link
                href="#contact"
                className="bg-gradient-to-r from-pink-600 to-pink-500 hover:from-pink-700 hover:to-pink-600 text-white px-8 py-4 rounded-full text-center font-medium transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-pink-600/30"
              >
                Quero saber mais!
              </Link>
              <Link
                href="#services"
                className="border border-pink-500/30 hover:border-pink-500 text-pink-600 px-8 py-4 rounded-full text-center font-medium transition-all duration-300 hover:bg-pink-50"
              >
                Conheça nossas soluções
              </Link>
            </motion.div>
          </motion.div>
        </div>
        <motion.div
          className="absolute bottom-10 left-1/2 transform -translate-x-1/2"
          variants={floatAnimation}
          initial="initial"
          animate="animate"
        >
          <ArrowDown className="h-10 w-10 text-pink-500" />
        </motion.div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50 relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-pink-500/30 to-transparent"></div>
          <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-pink-500/30 to-transparent"></div>
        </div>
        
        {/* Tech patterns */}
        <TechPattern variant="grid" color="rgba(236, 72, 153, 0.5)" opacity={0.05} />
        
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <motion.div
            className="grid grid-cols-2 md:grid-cols-4 gap-6"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
          >
            <motion.div
              className="bg-white p-8 rounded-3xl text-center shadow-lg border border-gray-100 hover:border-pink-500/30 transition-all duration-300 hover:shadow-xl"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <p className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-600 to-pink-500 mb-2">
                +200%
              </p>
              <p className="text-gray-600">de leads em 3 meses</p>
            </motion.div>
            <motion.div
              className="bg-white p-8 rounded-3xl text-center shadow-lg border border-gray-100 hover:border-pink-500/30 transition-all duration-300 hover:shadow-xl"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <p className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-600 to-pink-500 mb-2">
                80%
              </p>
              <p className="text-gray-600">de aumento em conversões</p>
            </motion.div>
            <motion.div
              className="bg-white p-8 rounded-3xl text-center shadow-lg border border-gray-100 hover:border-pink-500/30 transition-all duration-300 hover:shadow-xl"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <p className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-600 to-pink-500 mb-2">
                -35%
              </p>
              <p className="text-gray-600">no custo por aquisição</p>
            </motion.div>
            <motion.div
              className="bg-white p-8 rounded-3xl text-center shadow-lg border border-gray-100 hover:border-pink-500/30 transition-all duration-300 hover:shadow-xl"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <p className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-600 to-pink-500 mb-2">
                +150%
              </p>
              <p className="text-gray-600">de ROI em campanhas</p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Marketing Challenges Section */}
      <section className="py-24 bg-white text-gray-900 relative overflow-hidden">
        <div className="absolute inset-0 z-0 overflow-hidden">
          <motion.div
            className="absolute top-[10%] right-[5%] w-96 h-96 rounded-full bg-gradient-to-r from-pink-600/5 to-purple-600/5 blur-3xl"
            animate={{
              x: [0, -50, 0],
              y: [0, 30, 0],
            }}
            transition={{
              duration: 15,
              repeat: Number.POSITIVE_INFINITY,
              repeatType: "reverse",
            }}
          />
        </div>
        
        {/* Tech patterns */}
        <CircuitBoard color="rgba(236, 72, 153, 0.5)" opacity={0.05} />
        
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <motion.div
            className="text-center mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeIn}
          >
            <span className="inline-block bg-gradient-to-r from-pink-600/10 to-purple-600/10 backdrop-blur-md text-pink-600 px-6 py-2 rounded-full text-sm font-medium mb-4 border border-pink-500/20">
              DESAFIOS
            </span>
            <h2 className="text-3xl md:text-5xl font-bold mb-6 text-gray-900">Quais os principais desafios do seu marketing?</h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Identificamos e solucionamos os principais obstáculos que impedem o crescimento do seu negócio
            </p>
          </motion.div>

          <motion.div
            className="grid md:grid-cols-3 gap-8"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
          >
            <motion.div
              className="bg-white p-8 rounded-3xl border border-gray-100 shadow-lg hover:border-pink-500/30 transition-all duration-300 hover:shadow-xl group"
              variants={fadeIn}
              whileHover={{ y: -10 }}
            >
              <div className="bg-gradient-to-br from-pink-600/10 to-purple-600/10 p-5 rounded-2xl w-fit mb-6 group-hover:from-pink-600/20 group-hover:to-purple-600/20 transition-all duration-300">
                <TrendingUp className="h-7 w-7 text-pink-600" />
              </div>
              <h3 className="text-2xl font-bold mb-4 text-gray-900">Aumento nas vendas</h3>
              <p className="text-gray-600">
                Através de uma análise minuciosa de dados, nós avaliamos junto ao seu time comercial a qualificação de
                leads e criamos planos de ação estratégicos e personalizados para aumentarmos o desempenho de suas
                vendas.
              </p>
            </motion.div>

            <motion.div
              className="bg-white p-8 rounded-3xl border border-gray-100 shadow-lg hover:border-pink-500/30 transition-all duration-300 hover:shadow-xl group"
              variants={fadeIn}
              whileHover={{ y: -10 }}
            >
              <div className="bg-gradient-to-br from-pink-600/10 to-purple-600/10 p-5 rounded-2xl w-fit mb-6 group-hover:from-pink-600/20 group-hover:to-purple-600/20 transition-all duration-300">
                <BarChart3 className="h-7 w-7 text-pink-600" />
              </div>
              <h3 className="text-2xl font-bold mb-4 text-gray-900">Gestão ineficiente de orçamento</h3>
              <p className="text-gray-600">
                Otimizar o orçamento das campanhas pagas é crucial para maximizar o ROI. Com nossa experiência,
                garantimos que cada centavo seja gasto de forma eficiente, focando nas estratégias que trazem os
                melhores resultados.
              </p>
            </motion.div>

            <motion.div
              className="bg-white p-8 rounded-3xl border border-gray-100 shadow-lg hover:border-pink-500/30 transition-all duration-300 hover:shadow-xl group"
              variants={fadeIn}
              whileHover={{ y: -10 }}
            >
              <div className="bg-gradient-to-br from-pink-600/10 to-purple-600/10 p-5 rounded-2xl w-fit mb-6 group-hover:from-pink-600/20 group-hover:to-purple-600/20 transition-all duration-300">
                <Clock className="h-7 w-7 text-pink-600" />
              </div>
              <h3 className="text-2xl font-bold mb-4 text-gray-900">Falta de tempo</h3>
              <p className="text-gray-600">
                Gerenciar campanhas pagas pode ser uma tarefa demorada. Ao terceirizar a performance, você e sua equipe
                poderão se concentrar em outras áreas importantes do marketing, como a criação de conteúdo e estratégias
                de crescimento.
              </p>
            </motion.div>

            <motion.div
              className="bg-white p-8 rounded-3xl border border-gray-100 shadow-lg hover:border-pink-500/30 transition-all duration-300 hover:shadow-xl group"
              variants={fadeIn}
              whileHover={{ y: -10 }}
            >
              <div className="bg-gradient-to-br from-pink-600/10 to-purple-600/10 p-5 rounded-2xl w-fit mb-6 group-hover:from-pink-600/20 group-hover:to-purple-600/20 transition-all duration-300">
                <LineChart className="h-7 w-7 text-pink-600" />
              </div>
              <h3 className="text-2xl font-bold mb-4 text-gray-900">Resultados inconsistentes</h3>
              <p className="text-gray-600">
                Campanhas de mídia paga exigem monitoramento constante e ajustes precisos. Nossa abordagem baseada em
                dados e nossa dashboard atualizada em tempo real assegura que as campanhas do seu negócio estejam sempre
                otimizadas.
              </p>
            </motion.div>

            <motion.div
              className="bg-white p-8 rounded-3xl border border-gray-100 shadow-lg hover:border-pink-500/30 transition-all duration-300 hover:shadow-xl group"
              variants={fadeIn}
              whileHover={{ y: -10 }}
            >
              <div className="bg-gradient-to-br from-pink-600/10 to-purple-600/10 p-5 rounded-2xl w-fit mb-6 group-hover:from-pink-600/20 group-hover:to-purple-600/20 transition-all duration-300">
                <Target className="h-7 w-7 text-pink-600" />
              </div>
              <h3 className="text-2xl font-bold mb-4 text-gray-900">Estratégias de crescimento</h3>
              <p className="text-gray-600">
                O crescimento é mais do que um objetivo; é uma jornada. Juntos, podemos desenvolver estratégias que
                impulsionam seu crescimento imediato, estabelecendo bases sólidas para o sucesso contínuo do seu
                negócio.
              </p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* CTA Banner with Parallax */}
      <section className="py-24 relative overflow-hidden">
        <motion.div
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: "url('/pink-abstract-bg.png')",
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
          initial={{ y: 0 }}
          whileInView={{ y: -20 }}
          transition={{ duration: 1.5 }}
          viewport={{ once: false }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-pink-700/90 via-pink-600/90 to-purple-700/90"></div>
        
        {/* Tech patterns */}
        <TechPattern variant="waves" color="rgba(255, 255, 255, 0.3)" opacity={0.15} />
        <DataFlow color="rgba(255, 255, 255, 0.5)" opacity={0.1} speed="slow" />
        
        <div className="py-24 relative">
          <div className="container mx-auto px-4 md:px-6">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <motion.div
                className="text-left"
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-100px" }}
                variants={fadeIn}
              >
                <h2 className="text-3xl md:text-5xl font-bold mb-6 text-white">PERFORMANCE DE <br/><span className="text-white/90">ALTO NÍVEL</span></h2>
                <p className="text-xl mb-10 max-w-xl text-white/90">
                  Transformamos estratégias em resultados mensuráveis para o seu negócio através de análise de dados e otimização contínua.
                </p>
                <div className="flex flex-wrap gap-4 mb-8">
                  <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full">
                    <motion.div 
                      animate={{ rotate: 360 }}
                      transition={{ duration: 8, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                      className="text-white"
                    >
                      <TrendingUp size={20} />
                    </motion.div>
                    <span className="text-sm text-white">Crescimento acelerado</span>
                  </div>
                  <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full">
                    <motion.div 
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                      className="text-white"
                    >
                      <Target size={20} />
                    </motion.div>
                    <span className="text-sm text-white">Resultados precisos</span>
                  </div>
                  <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full">
                    <motion.div 
                      animate={{ y: [0, -5, 0] }}
                      transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                      className="text-white"
                    >
                      <BarChart2 size={20} />
                    </motion.div>
                    <span className="text-sm text-white">Métricas em tempo real</span>
                  </div>
                </div>
                <Link
                  href="#contact"
                  className="bg-white hover:bg-white/90 text-pink-600 font-medium px-10 py-5 rounded-full text-center inline-flex items-center gap-2 transition-all duration-300 hover:gap-3 shadow-lg shadow-pink-600/20"
                >
                  Falar com Especialista
                  <ChevronRight className="h-5 w-5" />
                </Link>
              </motion.div>
              
              <motion.div
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-100px" }}
                variants={fadeIn}
                className="relative h-[400px] hidden md:block"
              >
                <div className="absolute inset-0 flex items-center justify-center">
                  <motion.div 
                    className="relative w-64 h-64"
                    animate={{ rotate: 360 }}
                    transition={{ duration: 50, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                  >
                    <div className="absolute inset-0 rounded-full border-4 border-dashed border-white/20"></div>
                  </motion.div>
                  
                  <motion.div 
                    className="absolute w-48 h-48 rounded-full bg-gradient-to-r from-pink-500/20 to-purple-500/20 backdrop-blur-md"
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 8, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse" }}
                  ></motion.div>
                  
                  <motion.div 
                    className="absolute flex flex-col items-center justify-center text-center"
                    animate={{ scale: [0.9, 1, 0.9] }}
                    transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse" }}
                  >
                    <div className="bg-white/10 backdrop-blur-md p-6 rounded-full mb-4">
                      <motion.div
                        animate={{ 
                          rotateY: [0, 180, 360],
                          scale: [1, 1.2, 1]
                        }}
                        transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
                      >
                        <Award className="h-12 w-12 text-white" />
                      </motion.div>
                    </div>
                    <p className="text-xl font-bold text-white">Resultados Comprovados</p>
                    <p className="text-sm text-white/80">Estratégias que funcionam</p>
                  </motion.div>
                  
                  <motion.div 
                    className="absolute top-0 left-20"
                    animate={{ y: [0, -15, 0] }}
                    transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse" }}
                  >
                    <div className="bg-white/10 backdrop-blur-md p-3 rounded-full">
                      <LineChart className="h-6 w-6 text-white" />
                    </div>
                  </motion.div>
                  
                  <motion.div 
                    className="absolute bottom-10 right-10"
                    animate={{ y: [0, 15, 0] }}
                    transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse", delay: 1 }}
                  >
                    <div className="bg-white/10 backdrop-blur-md p-3 rounded-full">
                      <BarChart3 className="h-6 w-6 text-white" />
                    </div>
                  </motion.div>
                  
                  <motion.div 
                    className="absolute bottom-20 left-0"
                    animate={{ x: [0, 15, 0] }}
                    transition={{ duration: 5, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse", delay: 0.5 }}
                  >
                    <div className="bg-white/10 backdrop-blur-md p-3 rounded-full">
                      <BrainCircuit className="h-6 w-6 text-white" />
                    </div>
                  </motion.div>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section ref={servicesRef} className="py-24 bg-white text-gray-900 relative overflow-hidden" id="services">
        <div className="absolute inset-0 z-0 overflow-hidden">
          <motion.div
            className="absolute bottom-[20%] left-[5%] w-96 h-96 rounded-full bg-gradient-to-r from-pink-600/5 to-purple-600/5 blur-3xl"
            animate={{
              x: [0, 50, 0],
              y: [0, -30, 0],
            }}
            transition={{
              duration: 15,
              repeat: Number.POSITIVE_INFINITY,
              repeatType: "reverse",
            }}
          />
        </div>
        
        {/* Tech patterns */}
        <TechPattern variant="hexagons" color="rgba(236, 72, 153, 0.5)" opacity={0.05} />
        <BinaryRain color="rgba(236, 72, 153, 0.5)" opacity={0.03} speed="slow" density="low" />
        
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <motion.div
            className="text-center mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeIn}
          >
            <span className="inline-block bg-gradient-to-r from-pink-600/10 to-purple-600/10 backdrop-blur-md text-pink-600 px-6 py-2 rounded-full text-sm font-medium mb-\
