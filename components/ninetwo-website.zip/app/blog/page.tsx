import Image from "next/image"
import Link from "next/link"

export default function BlogPage() {
  // Sample blog posts data
  const blogPosts = [
    {
      id: 1,
      title: "Como Otimizar Campanhas de Tráfego Pago",
      excerpt:
        "Aprenda estratégias avançadas para maximizar o ROI das suas campanhas de tráfego pago e aumentar suas conversões.",
      date: "12 Abr 2025",
      category: "Tráfego Pago",
      image: "/placeholder.svg?height=300&width=600",
    },
    {
      id: 2,
      title: "O Poder dos Dashboards em Tempo Real",
      excerpt:
        "Descubra como utilizar dashboards em tempo real para tomar decisões mais rápidas e eficientes para o seu negócio.",
      date: "05 Abr 2025",
      category: "Web Analytics",
      image: "/placeholder.svg?height=300&width=600",
    },
    {
      id: 3,
      title: "Estratégias de Marketing Digital para 2025",
      excerpt: "Conheça as principais tendências e estratégias de marketing digital que dominarão o mercado em 2025.",
      date: "28 Mar 2025",
      category: "Marketing Digital",
      image: "/placeholder.svg?height=300&width=600",
    },
    {
      id: 4,
      title: "Como Implementar uma Estratégia Omnichannel Eficiente",
      excerpt: "Aprenda a criar uma experiência consistente para seus clientes em todos os canais de comunicação.",
      date: "20 Mar 2025",
      category: "Business Intelligence",
      image: "/placeholder.svg?height=300&width=600",
    },
    {
      id: 5,
      title: "Métricas Essenciais para Monitorar em Suas Campanhas",
      excerpt:
        "Descubra quais métricas são fundamentais para avaliar o desempenho das suas campanhas de marketing digital.",
      date: "15 Mar 2025",
      category: "Web Analytics",
      image: "/placeholder.svg?height=300&width=600",
    },
    {
      id: 6,
      title: "Como Utilizar IA para Otimizar suas Estratégias de Marketing",
      excerpt: "Conheça as aplicações práticas da inteligência artificial para melhorar seus resultados de marketing.",
      date: "08 Mar 2025",
      category: "Business Intelligence",
      image: "/placeholder.svg?height=300&width=600",
    },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-sm">
        <div className="container mx-auto flex items-center justify-between py-4 px-4 md:px-6">
          <Link href="/" className="flex items-center">
            <div className="relative h-8 w-32">
              <Image src="/images/logo-ninetwo.png" alt="NineTwo Logo" fill className="object-contain" priority />
            </div>
          </Link>
          <nav className="hidden md:flex items-center gap-8">
            <Link href="/" className="text-white hover:text-pink-600 transition-colors">
              Home
            </Link>
            <Link href="/solucoes" className="text-white hover:text-pink-600 transition-colors">
              Soluções
            </Link>
            <Link href="/cases" className="text-white hover:text-pink-600 transition-colors">
              Cases
            </Link>
            <Link href="/blog" className="text-white hover:text-pink-600 transition-colors">
              Blog
            </Link>
            <Link
              href="/contato"
              className="bg-pink-600 hover:bg-pink-700 text-white px-4 py-2 rounded-md transition-colors"
            >
              Contato
            </Link>
          </nav>
          <button className="md:hidden text-white">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={1.5}
              stroke="currentColor"
              className="w-6 h-6"
            >
              <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
            </svg>
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-24 bg-black text-white">
        <div className="container mx-auto px-4 md:px-6 py-16">
          <div className="max-w-2xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Blog <span className="text-pink-600">NineTwo</span>
            </h1>
            <p className="text-lg text-gray-300 mb-8">
              Insights, estratégias e tendências sobre marketing digital, tráfego pago, web analytics e business
              intelligence.
            </p>
          </div>
        </div>
      </section>

      {/* Blog Posts */}
      <section className="py-16 bg-zinc-900">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post) => (
              <article
                key={post.id}
                className="bg-black rounded-lg overflow-hidden hover:transform hover:scale-[1.02] transition-all duration-300"
              >
                <Link href={`/blog/${post.id}`}>
                  <div className="relative h-48 w-full">
                    <Image src={post.image || "/placeholder.svg"} alt={post.title} fill className="object-cover" />
                  </div>
                  <div className="p-6">
                    <div className="flex items-center gap-2 mb-3">
                      <span className="text-xs font-medium text-pink-600">{post.category}</span>
                      <span className="text-xs text-gray-500">•</span>
                      <span className="text-xs text-gray-500">{post.date}</span>
                    </div>
                    <h2 className="text-xl font-bold mb-3 hover:text-pink-600 transition-colors">{post.title}</h2>
                    <p className="text-gray-400 mb-4">{post.excerpt}</p>
                    <div className="flex items-center text-pink-600 font-medium">
                      <span>Ler mais</span>
                      <svg className="w-4 h-4 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M14 5l7 7m0 0l-7 7m7-7H3"
                        />
                      </svg>
                    </div>
                  </div>
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-16 bg-black">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">Inscreva-se na nossa newsletter</h2>
            <p className="text-gray-400 mb-8">
              Receba as últimas novidades, dicas e estratégias de marketing digital diretamente na sua caixa de entrada.
            </p>
            <form className="flex flex-col sm:flex-row gap-2 max-w-lg mx-auto">
              <input
                type="email"
                placeholder="Seu email"
                className="flex-1 px-4 py-3 bg-zinc-900 border border-zinc-800 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-600 focus:border-transparent"
              />
              <button
                type="submit"
                className="bg-pink-600 hover:bg-pink-700 text-white px-6 py-3 rounded-md font-medium transition-colors"
              >
                Inscrever
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-zinc-900 text-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid md:grid-cols-3 gap-12 mb-12">
            <div>
              <div className="relative h-8 w-32 mb-4">
                <Image src="/images/logo-ninetwo.png" alt="NineTwo Logo" fill className="object-contain" />
              </div>
              <p className="text-gray-400 mb-4">Performance Digital para Resultados Reais.</p>
              <div className="flex gap-4">
                <a href="#" className="text-gray-400 hover:text-pink-600 transition-colors">
                  <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" />
                  </svg>
                </a>
                <a href="#" className="text-gray-400 hover:text-pink-600 transition-colors">
                  <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                  </svg>
                </a>
              </div>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">Links Rápidos</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/" className="text-gray-400 hover:text-pink-600 transition-colors">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/sobre" className="text-gray-400 hover:text-pink-600 transition-colors">
                    Sobre
                  </Link>
                </li>
                <li>
                  <Link href="/solucoes" className="text-gray-400 hover:text-pink-600 transition-colors">
                    Soluções
                  </Link>
                </li>
                <li>
                  <Link href="/cases" className="text-gray-400 hover:text-pink-600 transition-colors">
                    Cases
                  </Link>
                </li>
                <li>
                  <Link href="/blog" className="text-gray-400 hover:text-pink-600 transition-colors">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link href="/contato" className="text-gray-400 hover:text-pink-600 transition-colors">
                    Contato
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">Newsletter</h3>
              <p className="text-gray-400 mb-4">Inscreva-se para receber nossas atualizações e conteúdos exclusivos.</p>
              <form className="flex">
                <input
                  type="email"
                  placeholder="Seu email"
                  className="flex-1 px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-l-md focus:outline-none focus:ring-2 focus:ring-pink-600 focus:border-transparent"
                />
                <button
                  type="submit"
                  className="bg-pink-600 hover:bg-pink-700 text-white px-4 py-2 rounded-r-md transition-colors"
                >
                  Enviar
                </button>
              </form>
            </div>
          </div>
          <div className="border-t border-zinc-800 pt-8 text-center">
            <p className="text-gray-500">
              © {new Date().getFullYear()} Nine Two - Performance Digital. Todos os direitos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
