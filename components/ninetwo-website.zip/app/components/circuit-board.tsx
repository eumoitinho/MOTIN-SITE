"use client"

import { motion } from "framer-motion"
import { useEffect, useState } from "react"

interface CircuitBoardProps {
  color?: string
  opacity?: number
  animate?: boolean
  className?: string
}

export default function CircuitBoard({
  color = "rgba(236, 72, 153, 0.5)",
  opacity = 0.15,
  animate = true,
  className = "",
}: CircuitBoardProps) {
  const [paths, setPaths] = useState<Array<{ id: number; d: string; delay: number }>>([])
  const [nodes, setNodes] = useState<Array<{ id: number; x: number; y: number; delay: number }>>([])

  useEffect(() => {
    // Create circuit paths
    const circuitPaths = [
      { id: 1, d: "M10,30 L90,30 L90,70 L30,70 L30,90", delay: 0 },
      { id: 2, d: "M50,10 L50,50 L70,50 L70,90", delay: 1 },
      { id: 3, d: "M10,50 L40,50 L40,90", delay: 0.5 },
      { id: 4, d: "M30,10 L30,20 L60,20 L60,60 L90,60", delay: 1.5 },
      { id: 5, d: "M10,80 L20,80 L20,40 L80,40 L80,10", delay: 2 },
    ]

    // Create circuit nodes
    const circuitNodes = [
      { id: 1, x: 10, y: 30, delay: 0 },
      { id: 2, x: 90, y: 30, delay: 0.5 },
      { id: 3, x: 90, y: 70, delay: 1 },
      { id: 4, x: 30, y: 70, delay: 1.5 },
      { id: 5, x: 30, y: 90, delay: 2 },
      { id: 6, x: 50, y: 10, delay: 0 },
      { id: 7, x: 50, y: 50, delay: 0.5 },
      { id: 8, x: 70, y: 50, delay: 1 },
      { id: 9, x: 70, y: 90, delay: 1.5 },
      { id: 10, x: 10, y: 50, delay: 0 },
      { id: 11, x: 40, y: 50, delay: 0.5 },
      { id: 12, x: 40, y: 90, delay: 1 },
      { id: 13, x: 30, y: 10, delay: 0 },
      { id: 14, x: 60, y: 20, delay: 0.5 },
      { id: 15, x: 60, y: 60, delay: 1 },
      { id: 16, x: 90, y: 60, delay: 1.5 },
      { id: 17, x: 10, y: 80, delay: 0 },
      { id: 18, x: 20, y: 80, delay: 0.5 },
      { id: 19, x: 20, y: 40, delay: 1 },
      { id: 20, x: 80, y: 40, delay: 1.5 },
      { id: 21, x: 80, y: 10, delay: 2 },
    ]

    setPaths(circuitPaths)
    setNodes(circuitNodes)
  }, [])

  return (
    <div className={`absolute inset-0 ${className}`} style={{ opacity }}>
      <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
        {paths.map((path) => (
          <motion.path
            key={path.id}
            d={path.d}
            stroke={color}
            strokeWidth="0.5"
            fill="none"
            initial={{ pathLength: 0, opacity: 0.2 }}
            animate={
              animate
                ? {
                    pathLength: [0, 1, 0],
                    opacity: [0.2, 1, 0.2],
                  }
                : undefined
            }
            transition={
              animate
                ? {
                    pathLength: {
                      duration: 8,
                      repeat: Number.POSITIVE_INFINITY,
                      ease: "easeInOut",
                      delay: path.delay,
                    },
                    opacity: {
                      duration: 8,
                      repeat: Number.POSITIVE_INFINITY,
                      ease: "easeInOut",
                      delay: path.delay,
                    },
                  }
                : undefined
            }
          />
        ))}
        {nodes.map((node) => (
          <motion.circle
            key={node.id}
            cx={node.x}
            cy={node.y}
            r="0.8"
            fill={color}
            initial={{ opacity: 0.2 }}
            animate={
              animate
                ? {
                    opacity: [0.2, 1, 0.2],
                    r: [0.8, 1.2, 0.8],
                  }
                : undefined
            }
            transition={
              animate
                ? {
                    opacity: {
                      duration: 4,
                      repeat: Number.POSITIVE_INFINITY,
                      ease: "easeInOut",
                      delay: node.delay,
                    },
                    r: {
                      duration: 4,
                      repeat: Number.POSITIVE_INFINITY,
                      ease: "easeInOut",
                      delay: node.delay,
                    },
                  }
                : undefined
            }
          />
        ))}
      </svg>
    </div>
  )
}
