"use client"

import { motion } from "framer-motion"
import { useState } from "react"

interface AnimatedLinesProps {
  color?: string
  opacity?: number
  density?: "low" | "medium" | "high"
  className?: string
}

export default function AnimatedLines({
  color = "rgba(236, 72, 153, 0.5)",
  opacity = 0.15,
  density = "medium",
  className = "",
}: AnimatedLinesProps) {
  const [patternId] = useState(`pattern-${Math.random().toString(36).substring(2, 9)}`)

  // Determine line spacing based on density
  const getSpacing = () => {
    switch (density) {
      case "low":
        return 80
      case "high":
        return 30
      default:
        return 50
    }
  }

  const spacing = getSpacing()

  return (
    <svg
      className={`absolute inset-0 w-full h-full ${className}`}
      xmlns="http://www.w3.org/2000/svg"
      width="100%"
      height="100%"
      style={{ opacity }}
    >
      <defs>
        <pattern id={patternId} patternUnits="userSpaceOnUse" width={spacing} height={spacing}>
          <rect width="100%" height="100%" fill="none" />
          <motion.g
            animate={{
              rotate: [0, 360],
            }}
            transition={{
              duration: 120,
              repeat: Number.POSITIVE_INFINITY,
              ease: "linear",
            }}
            style={{ transformOrigin: `${spacing / 2}px ${spacing / 2}px` }}
          >
            <line x1="0" y1={spacing / 2} x2={spacing} y2={spacing / 2} stroke={color} strokeWidth="0.3" />
            <line x1={spacing / 2} y1="0" x2={spacing / 2} y2={spacing} stroke={color} strokeWidth="0.3" />
            <line x1="0" y1="0" x2={spacing} y2={spacing} stroke={color} strokeWidth="0.3" />
            <line x1="0" y1={spacing} x2={spacing} y2="0" stroke={color} strokeWidth="0.3" />
          </motion.g>
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill={`url(#${patternId})`} />
    </svg>
  )
}
