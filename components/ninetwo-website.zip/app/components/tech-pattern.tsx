"use client"

import { motion } from "framer-motion"
import { useState } from "react"

interface TechPatternProps {
  variant?: "grid" | "circuit" | "dots" | "waves" | "hexagons" | "lines"
  color?: string
  opacity?: number
  animate?: boolean
  className?: string
}

export default function TechPattern({
  variant = "grid",
  color = "rgba(236, 72, 153, 0.3)",
  opacity = 0.15,
  animate = true,
  className = "",
}: TechPatternProps) {
  const [patternId] = useState(`pattern-${Math.random().toString(36).substring(2, 9)}`)

  // Grid pattern
  const renderGridPattern = () => (
    <svg
      className={`absolute inset-0 w-full h-full ${className}`}
      xmlns="http://www.w3.org/2000/svg"
      width="100%"
      height="100%"
      style={{ opacity }}
    >
      <defs>
        <pattern
          id={patternId}
          patternUnits="userSpaceOnUse"
          width="40"
          height="40"
          patternTransform={animate ? "rotate(0)" : undefined}
        >
          <motion.rect
            width="100%"
            height="100%"
            fill="none"
            animate={animate ? { patternTransform: ["rotate(0)", "rotate(360)"] } : undefined}
            transition={animate ? { duration: 200, repeat: Number.POSITIVE_INFINITY, ease: "linear" } : undefined}
          />
          <path
            d="M 0,10 H 40 M 0,20 H 40 M 0,30 H 40 M 10,0 V 40 M 20,0 V 40 M 30,0 V 40"
            stroke={color}
            strokeWidth="0.5"
          />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill={`url(#${patternId})`} />
    </svg>
  )

  // Circuit pattern
  const renderCircuitPattern = () => (
    <svg
      className={`absolute inset-0 w-full h-full ${className}`}
      xmlns="http://www.w3.org/2000/svg"
      width="100%"
      height="100%"
      style={{ opacity }}
    >
      <defs>
        <pattern id={patternId} patternUnits="userSpaceOnUse" width="100" height="100">
          <rect width="100%" height="100%" fill="none" />
          <motion.g
            animate={
              animate
                ? {
                    opacity: [0.5, 1, 0.5],
                    scale: [1, 1.02, 1],
                  }
                : undefined
            }
            transition={
              animate
                ? {
                    duration: 5,
                    repeat: Number.POSITIVE_INFINITY,
                    repeatType: "reverse",
                    ease: "easeInOut",
                  }
                : undefined
            }
          >
            <path d="M10,30 L40,30 L40,10 L70,10 L70,50 L90,50" stroke={color} strokeWidth="1" fill="none" />
            <path d="M30,10 L30,40 L50,40 L50,70 L80,70 L80,40" stroke={color} strokeWidth="1" fill="none" />
            <circle cx="10" cy="30" r="2" fill={color} />
            <circle cx="40" cy="10" r="2" fill={color} />
            <circle cx="70" cy="50" r="2" fill={color} />
            <circle cx="90" cy="50" r="2" fill={color} />
            <circle cx="30" cy="40" r="2" fill={color} />
            <circle cx="50" cy="70" r="2" fill={color} />
            <circle cx="80" cy="40" r="2" fill={color} />
          </motion.g>
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill={`url(#${patternId})`} />
    </svg>
  )

  // Dots pattern
  const renderDotsPattern = () => (
    <svg
      className={`absolute inset-0 w-full h-full ${className}`}
      xmlns="http://www.w3.org/2000/svg"
      width="100%"
      height="100%"
      style={{ opacity }}
    >
      <defs>
        <pattern id={patternId} patternUnits="userSpaceOnUse" width="20" height="20">
          <rect width="100%" height="100%" fill="none" />
          <motion.g
            animate={
              animate
                ? {
                    scale: [1, 1.2, 1],
                  }
                : undefined
            }
            transition={
              animate
                ? {
                    duration: 3,
                    repeat: Number.POSITIVE_INFINITY,
                    repeatType: "reverse",
                    ease: "easeInOut",
                    staggerChildren: 0.1,
                  }
                : undefined
            }
          >
            <circle cx="10" cy="10" r="1" fill={color} />
          </motion.g>
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill={`url(#${patternId})`} />
    </svg>
  )

  // Waves pattern
  const renderWavesPattern = () => (
    <svg
      className={`absolute inset-0 w-full h-full ${className}`}
      xmlns="http://www.w3.org/2000/svg"
      width="100%"
      height="100%"
      style={{ opacity }}
    >
      <defs>
        <pattern id={patternId} patternUnits="userSpaceOnUse" width="100" height="50">
          <rect width="100%" height="100%" fill="none" />
          <motion.path
            d="M0,25 Q25,0 50,25 T100,25"
            stroke={color}
            strokeWidth="1"
            fill="none"
            animate={
              animate
                ? {
                    y: [0, 5, 0],
                  }
                : undefined
            }
            transition={
              animate
                ? {
                    duration: 10,
                    repeat: Number.POSITIVE_INFINITY,
                    ease: "easeInOut",
                  }
                : undefined
            }
          />
          <motion.path
            d="M0,25 Q25,50 50,25 T100,25"
            stroke={color}
            strokeWidth="1"
            fill="none"
            animate={
              animate
                ? {
                    y: [0, -5, 0],
                  }
                : undefined
            }
            transition={
              animate
                ? {
                    duration: 8,
                    repeat: Number.POSITIVE_INFINITY,
                    ease: "easeInOut",
                  }
                : undefined
            }
          />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill={`url(#${patternId})`} />
    </svg>
  )

  // Hexagons pattern
  const renderHexagonsPattern = () => (
    <svg
      className={`absolute inset-0 w-full h-full ${className}`}
      xmlns="http://www.w3.org/2000/svg"
      width="100%"
      height="100%"
      style={{ opacity }}
    >
      <defs>
        <pattern id={patternId} patternUnits="userSpaceOnUse" width="60" height="60">
          <rect width="100%" height="100%" fill="none" />
          <motion.g
            animate={
              animate
                ? {
                    opacity: [0.5, 1, 0.5],
                    scale: [1, 1.05, 1],
                  }
                : undefined
            }
            transition={
              animate
                ? {
                    duration: 8,
                    repeat: Number.POSITIVE_INFINITY,
                    repeatType: "reverse",
                    ease: "easeInOut",
                  }
                : undefined
            }
          >
            <path
              d="M30,0 L60,17.32 L60,51.96 L30,69.28 L0,51.96 L0,17.32 Z"
              stroke={color}
              strokeWidth="1"
              fill="none"
            />
          </motion.g>
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill={`url(#${patternId})`} />
    </svg>
  )

  // Adicionar um novo padrão de linhas finas
  const renderLinesPattern = () => (
    <svg
      className={`absolute inset-0 w-full h-full ${className}`}
      xmlns="http://www.w3.org/2000/svg"
      width="100%"
      height="100%"
      style={{ opacity }}
    >
      <defs>
        <pattern
          id={patternId}
          patternUnits="userSpaceOnUse"
          width="60"
          height="60"
          patternTransform={animate ? "rotate(0)" : undefined}
        >
          <motion.rect
            width="100%"
            height="100%"
            fill="none"
            animate={animate ? { patternTransform: ["rotate(0)", "rotate(360)"] } : undefined}
            transition={animate ? { duration: 150, repeat: Number.POSITIVE_INFINITY, ease: "linear" } : undefined}
          />
          <path
            d="M 0,15 H 60 M 0,30 H 60 M 0,45 H 60 M 15,0 V 60 M 30,0 V 60 M 45,0 V 60"
            stroke={color}
            strokeWidth="0.3"
          />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill={`url(#${patternId})`} />
    </svg>
  )

  const renderPattern = () => {
    switch (variant) {
      case "grid":
        return renderGridPattern()
      case "circuit":
        return renderCircuitPattern()
      case "dots":
        return renderDotsPattern()
      case "waves":
        return renderWavesPattern()
      case "hexagons":
        return renderHexagonsPattern()
      case "lines":
        return renderLinesPattern()
      default:
        return renderGridPattern()
    }
  }

  return renderPattern()
}
