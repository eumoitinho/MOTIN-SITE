"use client"

import { motion } from "framer-motion"
import { useEffect, useState } from "react"

interface DataFlowProps {
  color?: string
  opacity?: number
  speed?: "slow" | "medium" | "fast"
  density?: "low" | "medium" | "high"
  className?: string
}

export default function DataFlow({
  color = "rgba(236, 72, 153, 0.5)",
  opacity = 0.2,
  speed = "medium",
  density = "medium",
  className = "",
}: DataFlowProps) {
  const [particles, setParticles] = useState<Array<{ id: number; x: number; y: number; size: number; speed: number }>>(
    [],
  )

  useEffect(() => {
    // Determine number of particles based on density
    let particleCount = 20
    if (density === "low") particleCount = 10
    if (density === "high") particleCount = 30

    // Create initial particles
    const initialParticles = Array.from({ length: particleCount }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 2 + 1,
      speed: Math.random() * 2 + 1,
    }))

    setParticles(initialParticles)
  }, [density])

  // Determine animation duration based on speed
  const getDuration = () => {
    switch (speed) {
      case "slow":
        return 15
      case "fast":
        return 5
      default:
        return 10
    }
  }

  return (
    <div className={`absolute inset-0 overflow-hidden ${className}`} style={{ opacity }}>
      {particles.map((particle) => (
        <motion.div
          key={particle.id}
          className="absolute rounded-full"
          style={{
            backgroundColor: color,
            width: `${particle.size}px`,
            height: `${particle.size}px`,
            left: `${particle.x}%`,
            top: `${particle.y}%`,
          }}
          animate={{
            y: ["0%", "100%"],
            opacity: [0, 1, 0],
          }}
          transition={{
            y: {
              duration: getDuration() * particle.speed,
              repeat: Number.POSITIVE_INFINITY,
              ease: "linear",
            },
            opacity: {
              duration: getDuration() * particle.speed,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut",
            },
          }}
        />
      ))}
    </div>
  )
}
