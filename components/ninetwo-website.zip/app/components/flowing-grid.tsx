"use client"

import { motion } from "framer-motion"
import { useState } from "react"

interface FlowingGridProps {
  color?: string
  opacity?: number
  lineWidth?: number
  className?: string
}

export default function FlowingGrid({
  color = "rgba(236, 72, 153, 0.5)",
  opacity = 0.15,
  lineWidth = 0.3,
  className = "",
}: FlowingGridProps) {
  const [patternId] = useState(`pattern-${Math.random().toString(36).substring(2, 9)}`)

  return (
    <div className={`absolute inset-0 overflow-hidden ${className}`} style={{ opacity }}>
      <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">
        <defs>
          <pattern id={patternId} patternUnits="userSpaceOnUse" width="40" height="40">
            <rect width="40" height="40" fill="none" />
            <motion.g
              animate={{
                y: [0, 40],
              }}
              transition={{
                duration: 20,
                repeat: Number.POSITIVE_INFINITY,
                ease: "linear",
              }}
            >
              <line x1="0" y1="0" x2="40" y2="0" stroke={color} strokeWidth={lineWidth} />
              <line x1="0" y1="10" x2="40" y2="10" stroke={color} strokeWidth={lineWidth} />
              <line x1="0" y1="20" x2="40" y2="20" stroke={color} strokeWidth={lineWidth} />
              <line x1="0" y1="30" x2="40" y2="30" stroke={color} strokeWidth={lineWidth} />
            </motion.g>
            <motion.g
              animate={{
                x: [0, 40],
              }}
              transition={{
                duration: 20,
                repeat: Number.POSITIVE_INFINITY,
                ease: "linear",
              }}
            >
              <line x1="0" y1="0" x2="0" y2="40" stroke={color} strokeWidth={lineWidth} />
              <line x1="10" y1="0" x2="10" y2="40" stroke={color} strokeWidth={lineWidth} />
              <line x1="20" y1="0" x2="20" y2="40" stroke={color} strokeWidth={lineWidth} />
              <line x1="30" y1="0" x2="30" y2="40" stroke={color} strokeWidth={lineWidth} />
            </motion.g>
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill={`url(#${patternId})`} />
      </svg>
    </div>
  )
}
