"use client"

import { motion } from "framer-motion"
import { useEffect, useState } from "react"

interface BinaryRainProps {
  color?: string
  opacity?: number
  speed?: "slow" | "medium" | "fast"
  density?: "low" | "medium" | "high"
  className?: string
}

export default function BinaryRain({
  color = "rgba(236, 72, 153, 0.5)",
  opacity = 0.15,
  speed = "medium",
  density = "medium",
  className = "",
}: BinaryRainProps) {
  const [columns, setColumns] = useState<Array<{ id: number; x: number; chars: string[] }>>([])

  useEffect(() => {
    // Determine number of columns based on density
    let columnCount = 15
    if (density === "low") columnCount = 8
    if (density === "high") columnCount = 25

    // Create columns with binary characters
    const initialColumns = Array.from({ length: columnCount }, (_, i) => {
      const chars = Array.from({ length: Math.floor(Math.random() * 10) + 5 }, () => (Math.random() > 0.5 ? "1" : "0"))
      return {
        id: i,
        x: Math.random() * 100,
        chars,
      }
    })

    setColumns(initialColumns)
  }, [density])

  // Determine animation duration based on speed
  const getDuration = () => {
    switch (speed) {
      case "slow":
        return 10
      case "fast":
        return 3
      default:
        return 6
    }
  }

  return (
    <div className={`absolute inset-0 overflow-hidden ${className}`} style={{ opacity }}>
      {columns.map((column) => (
        <motion.div
          key={column.id}
          className="absolute text-xs font-mono"
          style={{
            color,
            left: `${column.x}%`,
            top: "-20px",
          }}
          animate={{
            y: ["0vh", "100vh"],
          }}
          transition={{
            y: {
              duration: getDuration() * (Math.random() * 0.5 + 0.75),
              repeat: Number.POSITIVE_INFINITY,
              ease: "linear",
              repeatDelay: Math.random() * 2,
            },
          }}
        >
          {column.chars.map((char, i) => (
            <motion.div
              key={i}
              animate={{
                opacity: [0.3, 1, 0.3],
              }}
              transition={{
                opacity: {
                  duration: 2,
                  repeat: Number.POSITIVE_INFINITY,
                  ease: "easeInOut",
                  delay: i * 0.1,
                },
              }}
            >
              {char}
            </motion.div>
          ))}
        </motion.div>
      ))}
    </div>
  )
}
